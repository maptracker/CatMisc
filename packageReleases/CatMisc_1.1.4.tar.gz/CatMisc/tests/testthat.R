library(testthat)
library(CatMisc)

test_check("CatMisc")
